# Logistix360 v3.5.7 — Netlify

Pacote corrigido para publicação no Netlify.

## Correções desta versão

- Chat entre fornecedor, transportadora e admin passa a usar uma rota própria `/api/chat`, evitando depender do envio de uma nova mensagem pelo destinatário.
- O chat continua sendo atualizado automaticamente por polling e é redesenhado quando chega uma mensagem nova.
- Fornecedor pode abrir chamados na Central de Ajuda.
- Fornecedor e transportadora podem responder aos próprios chamados.
- Admin pode responder e resolver chamados.
- Relatórios Excel ficam disponíveis para fornecedor e transportadora, respeitando os pedidos que o servidor já entregou para aquele perfil.
- O backend mantém a segregação de dados por perfil.
- Os chamados também são validados no servidor; o fornecedor não pode criar um chamado em nome de outro perfil.

## Deploy

1. Substitua o conteúdo do projeto pelo pacote completo.
2. Mantenha as variáveis de ambiente:
   - `LOGISTIX_ADMIN_PASSWORD`
   - `LOGISTIX_FORNECEDOR_PASSWORD`
   - `LOGISTIX_TRANSPORTADORA_PASSWORD`
3. Faça um novo deploy.
4. Não apague o armazenamento existente.

## Observação

A atualização em tempo real desta versão usa polling de aproximadamente 1,5 segundo. Isso é atualização quase em tempo real, não WebSocket.


### Atraso manual
Fornecedor e Transportadora podem registrar atraso manual diretamente na carga, informando tipo, ocorrido e evidência opcional. O registro fica no histórico da carga e alimenta o status/indicadores de atraso.


### Cadastro de parceiros e e-mail opcional
- O e-mail do perfil é opcional; o cadastro e o login não dependem de código de verificação por e-mail.
- O Admin pode editar o e-mail sem fluxo de código, ou deixar o campo em branco.
- Para transportadoras, as UFs de cobertura podem ser selecionadas no cadastro/edição sem informar e-mail. É obrigatório selecionar ao menos uma UF ou a opção nacional.
- A lista de parceiros mostra o e-mail como opcional e não usa status de verificação por código.


### Correção de acesso ao Netlify Blobs (v3.5.6)
- A instância do armazenamento é resolvida dentro do contexto da requisição da Function, em vez de ser inicializada no carregamento do módulo.
- O nome do armazenamento permanece `logistix360-prod`; esta atualização não apaga nem recria os dados existentes.
- Após substituir o projeto, publique um novo deploy no Netlify. Não remova as variáveis de senha já configuradas.


### Dashboards: contagem exclusiva por status (v3.5.7)
- O status `Coletada` agora é uma etapa própria depois da confirmação da coleta.
- Os cards de Coletada contam apenas cargas cujo status atual é `Coletada`; ao iniciar o trânsito, a carga sai desse card e passa a contar em `Em Trânsito`.
- Ocorrências, rota e entrega continuam contabilizadas pelo status atual, evitando que uma carga permaneça simultaneamente em cards incompatíveis.
- Os cards dos dashboards receberam visual mais expressivo, profundidade, brilho sutil, elevação e animações de entrada/hover, respeitando a preferência de movimento reduzido do dispositivo.
- Para cargas já existentes, o status atual prevalece: cargas em trânsito não voltam a aparecer como Coletada só porque possuem histórico de coleta realizada.
